# Azure_deployment_project
To practice deploying a model on azure
